import * as mc from "@minecraft/server"
import * as gs from "../getScore";

mc.system.runInterval(() => {
    for (const player of mc.world.getPlayers()) {
        titles(player);
    }}, 2);

function titles(player) {
    //consts
    const cutscene = player.hasTag(`in_cutscene`) ? "[cutscene]" : "[no_cutscene]";
    const ene_max = gs.getScore(player, "ene_max");

    player.onScreenDisplay.setTitle(`[energy_${Math.round(gs.getScore(player, "ene") * 100 / gs.getScore(player, "ene_max"))}] ${cutscene}`);
    if (gs.getScore(player, "ene") > gs.getScore(player, "ene_max")) {
        player.runCommandAsync(`scoreboard players set @s ene ${ene_max}`);
    }
}